# Cloudflare Pages Deployment Guide

## ✅ Steps to Deploy
1. Upload all files to your GitHub repository root.
2. Connect the repository to Cloudflare Pages.
3. In **Build Settings**, set:
   - Framework preset: None
   - Build command: (leave empty)
   - Output directory: /
4. Click **Deploy** — your site will be available at `https://<project>.pages.dev`.
